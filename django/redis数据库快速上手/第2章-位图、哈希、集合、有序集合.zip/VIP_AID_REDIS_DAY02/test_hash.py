import redis

r = redis.Redis(host='127.0.0.1', port=6379, db=0)

r.hmset('pyh1',{'name':'wwc', 'age':60})
print(r.hgetall('pyh1'))