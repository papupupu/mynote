import redis
r = redis.Redis(host='127.0.0.1', port=6379, db=0)

####基础命令
#key_list = r.keys('*')
#print(key_list)
#[b'k3', b'l1', b'k2', b'uuuname', b'k1', b'uuname']
#print(r.type('l1'))

#####list######
#r.lpush('pyl1', 'a', 'v', 'w', 'z')
#print(r.lrange('pyl1',0,-1))
# r.linsert('pyl1','before','v','g')
# print(r.lrange('pyl1',0,-1))

####string####
# r.set('puname', 'guoxiaonao',ex=30)
# print(r.get('puname'))
#r.mset({'k1':'v1', 'k2':'v2'})
print(r.mget('k1','k2','k3','k6'))