import redis
import json
r = redis.Redis(host='127.0.0.1', port=6379, db=0)

json_obj = {'task':'send_email','email_body':'aaa', 'from':'bbb','to':'gxn'}
json_str = json.dumps(json_obj)
r.lpush('pyl2', json_str)
